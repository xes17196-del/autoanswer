package com.yuanbao.autoanswer.capture

import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection

/**
 * 一个 MediaProjection 只创建一次 VirtualDisplay，之后持续从 ImageReader 取最新帧。
 * 这一点在 Android 14+ 是硬要求：同一实例重复 createVirtualDisplay 会抛 SecurityException。
 */
class ScreenCapturer(
    private val projection: MediaProjection,
    private val width: Int,
    private val height: Int,
    private val dpi: Int
) {
    private val reader: ImageReader =
        ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3)
    private var display: VirtualDisplay? = null

    fun start() {
        display = projection.createVirtualDisplay(
            "auto-answer",
            width, height, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, null
        )
    }

    /** 没有新帧时返回 null，由上层循环稍后重试 */
    fun grab(): Bitmap? {
        val image = reader.acquireLatestImage() ?: return null
        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * width

            val tmp = Bitmap.createBitmap(
                width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888
            )
            tmp.copyPixelsFromBuffer(buffer)
            // RGBA -> ARGB 在部分机型上会有红蓝互换，不影响文字轮廓与 OCR
            val out = Bitmap.createBitmap(tmp, 0, 0, width, height)
            tmp.recycle()
            return out
        } finally {
            image.close()
        }
    }

    fun release() {
        display?.release()
        display = null
        reader.close()
    }
}
