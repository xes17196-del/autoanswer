package com.yuanbao.autoanswer.core

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import com.yuanbao.autoanswer.LogBus

/**
 * 只做一件事：用系统无障碍手势在指定坐标模拟一次点击。
 * 不读取窗口内容、不监听事件、不联网。
 */
class AutoClickAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onServiceConnected() {
        instance = this
        LogBus.log("无障碍服务已连接，可以模拟点击")
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        private var instance: AutoClickAccessibilityService? = null

        val isReady: Boolean get() = instance != null

        fun click(x: Float, y: Float): Boolean {
            val svc = instance ?: return false
            val path = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(path, 0L, 60L)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            return svc.dispatchGesture(
                gesture,
                object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(g: GestureDescription?) {
                        LogBus.log("点击完成 @(${x.toInt()}, ${y.toInt()})")
                    }

                    override fun onCancelled(g: GestureDescription?) {
                        LogBus.log("点击被系统取消")
                    }
                },
                null
            )
        }
    }
}
