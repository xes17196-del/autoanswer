package com.yuanbao.autoanswer.core

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.yuanbao.autoanswer.LogBus
import kotlinx.coroutines.suspendCancellableCoroutine

// ---------- 数据模型 ----------

/** OCR 的一行文本 + 其包围盒中心（坐标来自缩放后的截屏） */
data class OcrLine(val text: String, val cx: Float, val cy: Float, val top: Int)

data class Option(val label: Char, val text: String, val x: Float, val y: Float)

data class Question(val stem: String, val options: List<Option>)

// ---------- 屏幕文字识别 ----------

class OcrEngine {
    // 捆绑式中文识别器：简体中文 + 拉丁字母，模型随 APK 安装，全程离线
    private val recognizer =
        TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())

    suspend fun recognize(bitmap: Bitmap): List<OcrLine> =
        suspendCancellableCoroutine { cont ->
            val image = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(image)
                .addOnSuccessListener { result ->
                    val lines = result.textBlocks
                        .asSequence()
                        .flatMap { it.lines.asSequence() }
                        .mapNotNull { line ->
                            val box: Rect = line.boundingBox ?: return@mapNotNull null
                            val t = line.text.trim()
                            if (t.isEmpty()) null
                            else OcrLine(t, box.exactCenterX(), box.exactCenterY(), box.top)
                        }
                        .sortedBy { it.top }
                        .toList()
                    if (cont.isActive) cont.resumeWith(Result.success(lines))
                }
                .addOnFailureListener { e ->
                    LogBus.log("OCR 失败：${e.message}")
                    if (cont.isActive) cont.resumeWith(Result.success(emptyList<OcrLine>()))
                }
        }
}

// ---------- 从 OCR 行里还原「题干 + 选项坐标」 ----------

class QuestionParser {
    private val optionRegex =
        Regex("^[（(]?\\s*([A-Da-d])\\s*[)）.、．.：:]\\s*(.+)$")

    fun parse(lines: List<OcrLine>): Question? {
        val options = mutableListOf<Option>()
        var firstOptionIndex = -1

        lines.forEachIndexed { index, line ->
            val m = optionRegex.find(line.text) ?: return@forEachIndexed
            val label = m.groupValues[1].uppercase().first()
            if (options.none { it.label == label }) {
                if (firstOptionIndex < 0) firstOptionIndex = index
                options += Option(label, m.groupValues[2].trim(), line.cx, line.cy)
            }
        }

        if (options.size < 2 || firstOptionIndex <= 0) return null
        val stem = lines.take(firstOptionIndex).joinToString(" ") { it.text }
        if (stem.isBlank()) return null
        return Question(stem, options.sortedBy { it.label })
    }
}

// ---------- 答题策略（可替换成题库 / 本地模型 / LLM） ----------

interface Solver {
    /** 返回选项下标；返回 null 表示没把握，这一题跳过、不乱点 */
    fun solve(stem: String, options: List<String>): Int?
}

/**
 * 演示用本地规则求解器：题干关键词 → 正确选项里的关键词。
 * 想提升答对率，只需替换这个类：
 *   class LlmSolver(...) : Solver { override fun solve(...) = 调用你的模型端点 }
 * 注意网络请求要放在 IO 线程，别阻塞截屏循环。
 */
class LocalRuleSolver : Solver {

    private val bank = listOf(
        "首都" to listOf("北京"),
        "水的化学式" to listOf("H2O", "H₂O", "H2 0"),
        "太阳从" to listOf("东"),
        "1+1" to listOf("2"),
        "圆周率" to listOf("3.14"),
    )

    override fun solve(stem: String, options: List<String>): Int? {
        val s = norm(stem)
        for ((key, answers) in bank) {
            if (!s.contains(norm(key))) continue
            val idx = options.indexOfFirst { o -> answers.any { norm(o).contains(norm(it)) } }
            if (idx >= 0) return idx
        }
        return null
    }

    private fun norm(s: String) = s.replace(Regex("[\\s，,。.、？?：:]"), "")
}
