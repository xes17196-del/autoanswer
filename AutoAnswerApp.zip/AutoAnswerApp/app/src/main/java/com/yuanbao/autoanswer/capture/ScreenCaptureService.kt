package com.yuanbao.autoanswer.capture

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import com.yuanbao.autoanswer.LogBus
import com.yuanbao.autoanswer.MainActivity
import com.yuanbao.autoanswer.core.AutoClickAccessibilityService
import com.yuanbao.autoanswer.core.LocalRuleSolver
import com.yuanbao.autoanswer.core.OcrEngine
import com.yuanbao.autoanswer.core.QuestionParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * 两件事彻底分开：
 *  - ACTION_SETUP：只把 MediaProjection 会话建好（VirtualDisplay 起一次，持续取帧），不跑识别循环
 *  - ACTION_START / ACTION_PAUSE：由界面上那个独立开关单独控制循环的启停
 * 暂停时保留会话，所以反复拨开关不用重新弹系统授权窗。
 */
class ScreenCaptureService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loopJob: Job? = null
    private var projection: MediaProjection? = null
    private var capturer: ScreenCapturer? = null
    private var realW = 0
    private var realH = 0
    private var realDpi = 0

    companion object {
        private const val CHANNEL_ID = "auto_answer_capture"
        private const val NOTIF_ID = 1
        private const val CAPTURE_WIDTH = 1080   // 2K 屏先降采样，OCR 更快且省内存

        const val ACTION_SETUP = "com.yuanbao.autoanswer.SETUP"
        const val ACTION_START = "com.yuanbao.autoanswer.START"
        const val ACTION_PAUSE = "com.yuanbao.autoanswer.PAUSE"
        const val ACTION_RELEASE = "com.yuanbao.autoanswer.RELEASE"

        @Volatile private var sessionAlive = false
        @Volatile private var loopRunning = false

        @JvmStatic fun isSessionAlive() = sessionAlive
        @JvmStatic fun isLoopRunning() = loopRunning
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SETUP -> {
                // Android 14+：带 mediaProjection 类型的前台通知必须先于 getMediaProjection
                createChannel()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(
                        NOTIF_ID, buildNotification(),
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                    )
                } else {
                    startForeground(NOTIF_ID, buildNotification())
                }
                setup(intent)
            }

            ACTION_START -> {
                if (sessionAlive && projection != null) {
                    startLoop()
                } else {
                    LogBus.log("屏幕共享会话已失效（常被锁屏或系统回收），请重新点「2. 授权屏幕共享」")
                }
            }

            ACTION_PAUSE -> pauseLoop()

            ACTION_RELEASE -> {
                pauseLoop()
                releaseCapture()
                stopSelf()
            }

            else -> {
                // 服务被系统重建但 token 已丢，不做任何自动操作
                LogBus.log("会话不存在，请按 ① → ② → ③ 重新走一遍")
            }
        }
        return START_STICKY
    }

    /** 只授权、只建会话，绝不启动识别循环 */
    private fun setup(intent: Intent) {
        val code = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data")

        if (code != Activity.RESULT_OK || data == null) {
            LogBus.log("缺少有效的截屏授权，服务退出")
            stopSelf()
            return
        }

        // 重复授权时先把旧会话干净放掉，避免同一 token 上重复建 VirtualDisplay
        releaseCapture()

        val (w, h, dpi) = screenSize()
        realW = w; realH = h; realDpi = dpi

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(code, data)
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                // 旧会话被我们主动替换时会回调到这里，忽略它，别把新服务停掉
                if (projection !== mp) return
                sessionAlive = false
                loopRunning = false
                LogBus.log("系统结束了屏幕共享（锁屏 / 下拉停止投射），需重新授权")
                stopSelf()
            }
        }, Handler(Looper.getMainLooper()))
        projection = mp
        capturer = ScreenCapturer(mp, realW, realH, realDpi).also { it.start() }

        sessionAlive = true
        loopRunning = false
        LogBus.log("会话就绪：${realW}x${realH} → 识别宽度 $CAPTURE_WIDTH")
        LogBus.log("待命中：还没开始，等你在界面上拨「开始自动作答」开关")
    }

    /** 开关拨到「开」才调用 */
    private fun startLoop() {
        if (loopJob?.isActive == true) return
        loopJob?.cancel()
        loopJob = scope.launch { runLoop() }
        loopRunning = true
        updateNotification()
        LogBus.log("循环已启动：开始抓帧识别")
    }

    /** 开关拨到「关」：只停循环，VirtualDisplay 与 token 原样保留 */
    private fun pauseLoop() {
        loopJob?.cancel()
        loopJob = null
        loopRunning = false
        updateNotification()
        LogBus.log("循环已暂停（屏幕共享会话仍保留）")
    }

    /** 主循环：抓帧 → OCR → 还原题干与选项坐标 → 决策 → 点击 → 冷却 → 下一题 */
    private suspend fun runLoop() {
        val ocr = OcrEngine()
        val parser = QuestionParser()
        val solver = LocalRuleSolver()
        val capH = (CAPTURE_WIDTH.toFloat() * realH / realW).roundToInt()
        var lastStem = ""
        var lastTickLog = 0L
        var lastOcrLog = 0L

        while (currentCoroutineContext().isActive) {
            val raw = capturer?.grab()
            if (raw == null) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastTickLog > 3000) {
                    LogBus.log("等待屏幕帧…（若一直停在这里，检查是否锁屏或停在投射禁止页）")
                    lastTickLog = now
                }
                delay(150)
                continue
            }
            val scaled = Bitmap.createScaledBitmap(raw, CAPTURE_WIDTH, capH, true)
            raw.recycle()

            val lines = ocr.recognize(scaled)
            val question = parser.parse(lines)
            scaled.recycle()

            if (question == null) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastOcrLog > 3000) {
                    LogBus.log("取帧正常，OCR 得到 ${lines.size} 行，但没拼出「题干 + A/B/C/D」")
                    lastOcrLog = now
                }
                delay(500)
                continue
            }
            if (question.stem == lastStem) {   // 同一题不重复点
                delay(600)
                continue
            }

            LogBus.log("识别到题目：${question.stem.take(40)}（${question.options.size} 个选项）")
            val idx = solver.solve(question.stem, question.options.map { it.text })
            if (idx == null) {
                LogBus.log("题库未命中 → 按设计跳过，不乱点（演示题库只有几条关键词）")
                lastStem = question.stem
                delay(800)
                continue
            }

            if (!AutoClickAccessibilityService.isReady) {
                LogBus.log("无障碍未连接，无法点击 → 回系统设置重开开关")
                delay(800)
                continue
            }

            val opt = question.options[idx]
            val x = opt.x * realW / CAPTURE_WIDTH
            val y = opt.y * realH / capH
            if (AutoClickAccessibilityService.click(x, y)) {
                LogBus.log("选择 ${opt.label}：${opt.text.take(20)}")
                lastStem = question.stem
            }
            delay(1200)
        }
    }

    private fun releaseCapture() {
        pauseLoop()
        capturer?.release()
        capturer = null
        // 先解绑引用，stop() 触发的回调就会被判定为「旧会话」而忽略
        val old = projection
        projection = null
        old?.stop()
        sessionAlive = false
    }

    private fun updateNotification() {
        runCatching {
            getSystemService(NotificationManager::class.java)
                .notify(NOTIF_ID, buildNotification())
        }
    }

    private fun screenSize(): Triple<Int, Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            Triple(b.width(), b.height(), resources.configuration.densityDpi)
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            Triple(m.widthPixels, m.heightPixels, m.densityDpi)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(
                CHANNEL_ID, "屏幕识别", NotificationManager.IMPORTANCE_LOW
            )
            nm.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("AutoAnswer")
            .setContentText(
                if (loopRunning) "自动作答运行中 · 点此回到开关"
                else "已就绪 · 等你在 App 里拨「开始」开关"
            )
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        loopJob?.cancel()
        capturer?.release()
        val old = projection
        projection = null
        old?.stop()
        sessionAlive = false
        loopRunning = false
        scope.cancel()
        LogBus.log("截屏服务已结束（重新打开 App 按 ① → ② → ③ 走一遍）")
        super.onDestroy()
    }
}
