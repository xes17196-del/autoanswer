package com.yuanbao.autoanswer.capture

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import com.yuanbao.autoanswer.LogBus
import com.yuanbao.autoanswer.R
import com.yuanbao.autoanswer.core.AutoClickAccessibilityService
import com.yuanbao.autoanswer.core.LocalRuleSolver
import com.yuanbao.autoanswer.core.OcrEngine
import com.yuanbao.autoanswer.core.QuestionParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class ScreenCaptureService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loopJob: Job? = null
    private var projection: MediaProjection? = null
    private var capturer: ScreenCapturer? = null

    companion object {
        private const val CHANNEL_ID = "auto_answer_capture"
        private const val NOTIF_ID = 1
        private const val CAPTURE_WIDTH = 1080   // 2K 屏先降采样，OCR 更快且省内存
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIF_ID, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIF_ID, notification)
        }

        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")

        if (code != Activity.RESULT_OK || data == null) {
            LogBus.log("缺少有效的截屏授权，服务退出")
            stopSelf()
            return START_NOT_STICKY
        }

        // Android 14+：token 单次使用，且 createVirtualDisplay 前必须注册 Callback
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(code, data)
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                LogBus.log("系统结束了截屏会话")
                stopSelf()
            }
        }, Handler(Looper.getMainLooper()))
        projection = mp

        val (realW, realH, dpi) = screenSize()
        capturer = ScreenCapturer(mp, realW, realH, dpi).also { it.start() }

        loopJob?.cancel()
        loopJob = scope.launch { runLoop(realW, realH) }
        LogBus.log("截屏服务启动：${realW}x${realH} → 识别宽度 $CAPTURE_WIDTH")
        return START_STICKY
    }

    /** 主循环：抓帧 → OCR → 还原题干与选项坐标 → 决策 → 点击 → 冷却 → 下一题 */
    private suspend fun runLoop(realW: Int, realH: Int) {
        val ocr = OcrEngine()
        val parser = QuestionParser()
        val solver = LocalRuleSolver()
        val capH = (CAPTURE_WIDTH.toFloat() * realH / realW).roundToInt()
        var lastStem = ""

        while (currentCoroutineContext().isActive) {
            val raw = capturer?.grab()
            if (raw == null) {
                delay(150)
                continue
            }
            val scaled = Bitmap.createScaledBitmap(raw, CAPTURE_WIDTH, capH, true)
            raw.recycle()

            val lines = ocr.recognize(scaled)
            val question = parser.parse(lines)
            scaled.recycle()

            if (question == null) {
                delay(500)
                continue
            }
            if (question.stem == lastStem) {   // 同一题不重复点
                delay(600)
                continue
            }

            LogBus.log("识别到题目：${question.stem.take(40)}（${question.options.size} 个选项）")
            val idx = solver.solve(question.stem, question.options.map { it.text })
            if (idx == null) {
                LogBus.log("题库未命中，跳过本题")
                lastStem = question.stem
                delay(800)
                continue
            }

            if (!AutoClickAccessibilityService.isReady) {
                LogBus.log("无障碍未连接，无法点击")
                delay(800)
                continue
            }

            val opt = question.options[idx]
            val x = opt.x * realW / CAPTURE_WIDTH
            val y = opt.y * realH / capH
            if (AutoClickAccessibilityService.click(x, y)) {
                LogBus.log("选择 ${opt.label}：${opt.text.take(20)}")
                lastStem = question.stem
            }
            delay(1200)
        }
    }

    private fun screenSize(): Triple<Int, Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            Triple(b.width(), b.height(), resources.configuration.densityDpi)
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            Triple(m.widthPixels, m.heightPixels, m.densityDpi)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(
                CHANNEL_ID, "屏幕识别", NotificationManager.IMPORTANCE_LOW
            )
            nm.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("AutoAnswer 正在识别屏幕")
            .setContentText("本地 OCR + 自动点击，随时可在 App 内停止")
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        loopJob?.cancel()
        capturer?.release()
        projection?.stop()
        scope.cancel()
        LogBus.log("截屏服务已停止")
        super.onDestroy()
    }
}
