package com.yuanbao.autoanswer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.yuanbao.autoanswer.capture.ScreenCaptureService
import com.yuanbao.autoanswer.core.AutoClickAccessibilityService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 极简日志总线：Service / 无障碍服务 / UI 共用 */
object LogBus {
    private val _lines = MutableStateFlow<List<String>>(emptyList())
    val lines = _lines.asStateFlow()

    fun log(msg: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        _lines.update { (it + "[$t] $msg").takeLast(150) }
    }

    fun clear() = _lines.update { emptyList() }
}

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvLog: TextView

    // 每次点「开始」都重新走系统授权弹窗；Android 14+ 的 MediaProjection token 是一次性的
    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            if (res.resultCode == Activity.RESULT_OK && res.data != null) {
                val i = Intent(this, ScreenCaptureService::class.java).apply {
                    putExtra("resultCode", res.resultCode)
                    putExtra("data", res.data)
                }
                startForegroundService(i)
                LogBus.log("截屏授权已通过，自动答题启动")
            } else {
                LogBus.log("截屏授权被取消")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tv_status)
        tvLog = findViewById(R.id.tv_log)

        findViewById<Button>(R.id.btn_acc).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            LogBus.log("请在系统设置里打开「AutoAnswer」无障碍服务")
        }

        findViewById<Button>(R.id.btn_start).setOnClickListener {
            if (!isAccessibilityOn()) {
                LogBus.log("无障碍未开启，先点第 1 步授权")
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                return@setOnClickListener
            }
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            captureLauncher.launch(mpm.createScreenCaptureIntent())
        }

        findViewById<Button>(R.id.btn_stop).setOnClickListener {
            stopService(Intent(this, ScreenCaptureService::class.java))
            LogBus.log("已请求停止")
        }

        findViewById<Button>(R.id.btn_clear).setOnClickListener { LogBus.clear() }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }

        lifecycleScope.launch {
            LogBus.lines.collect {
                tvLog.text = it.joinToString("\n")
                refreshStatus()
            }
        }
        LogBus.log("就绪。依次完成：无障碍 → 截屏授权")
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        tvStatus.text = "状态：无障碍 ${if (AutoClickAccessibilityService.isReady) "已连接 ✅" else "未开启 ❌"}"
    }

    private fun isAccessibilityOn(): Boolean {
        val enabled = Settings.Secure.getInt(
            contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0
        )
        if (enabled != 1) return false
        val flat = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return flat.split(':').any { it.contains(packageName, ignoreCase = true) }
    }
}
