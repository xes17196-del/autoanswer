package com.yuanbao.autoanswer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.yuanbao.autoanswer.capture.ScreenCaptureService
import com.yuanbao.autoanswer.core.AutoClickAccessibilityService
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 极简日志总线：Service / 无障碍服务 / UI 共用 */
object LogBus {
    private val _lines = MutableStateFlow<List<String>>(emptyList())
    val lines = _lines.asStateFlow()

    fun log(msg: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        _lines.update { (it + "[$t] $msg").takeLast(150) }
    }

    fun clear() = _lines.update { emptyList() }
}

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvLog: TextView
    private lateinit var switchRun: Switch

    /** 防止代码回写开关状态时误触发监听 */
    private var updatingSwitch = false

    /**
     * 屏幕共享授权：只建立会话，不启动识别循环。
     * 真正的「开始」完全交给下面那个独立开关。
     */
    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            if (res.resultCode == Activity.RESULT_OK && res.data != null) {
                val i = Intent(this, ScreenCaptureService::class.java).apply {
                    action = ScreenCaptureService.ACTION_SETUP
                    putExtra("resultCode", res.resultCode)
                    putExtra("data", res.data)
                }
                startForegroundService(i)
                LogBus.log("屏幕共享授权成功 ✅ 仅授权，还没开始 —— 请打开下方「开始」开关")
            } else {
                LogBus.log("屏幕共享授权被取消")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tv_status)
        tvLog = findViewById(R.id.tv_log)
        switchRun = findViewById(R.id.switch_run)

        // ① 无障碍：只开权限，不触发任何自动操作
        findViewById<Button>(R.id.btn_acc).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            LogBus.log("请在系统设置 → 已下载的服务里打开「AutoAnswer」")
        }

        // ② 屏幕共享：只授权，授权完停在「待命」，绝不自动跑
        findViewById<Button>(R.id.btn_auth).setOnClickListener {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            captureLauncher.launch(mpm.createScreenCaptureIntent())
        }

        // ③ 独立开关：两个前置都就绪后，由用户主动拨一下才启动循环
        switchRun.setOnCheckedChangeListener { _, checked ->
            if (updatingSwitch) return@setOnCheckedChangeListener
            if (checked) {
                if (!AutoClickAccessibilityService.isReady ||
                    !ScreenCaptureService.isSessionAlive()
                ) {
                    LogBus.log("前置没齐：先完成 ① 无障碍 和 ② 屏幕共享授权")
                    updatingSwitch = true
                    switchRun.isChecked = false
                    updatingSwitch = false
                    return@setOnCheckedChangeListener
                }
                startService(
                    Intent(this, ScreenCaptureService::class.java)
                        .setAction(ScreenCaptureService.ACTION_START)
                )
                LogBus.log("▶ 开关已打开：截屏 → OCR → 点击 循环启动")
                LogBus.log("提示：现在切到题目 App，别停在 AutoAnswer 界面上")
            } else {
                startService(
                    Intent(this, ScreenCaptureService::class.java)
                        .setAction(ScreenCaptureService.ACTION_PAUSE)
                )
                LogBus.log("■ 已暂停：只停循环，屏幕共享保留，再打开不用重新授权")
            }
        }

        // 自检：单独验一次无障碍手势是否真的能点，用来区分「权限掉了」和「题库没命中」
        findViewById<Button>(R.id.btn_selftest).setOnClickListener {
            val wm = getSystemService(WINDOW_SERVICE) as android.view.WindowManager
            val (w, h) = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val b = wm.currentWindowMetrics.bounds
                b.width() to b.height()
            } else {
                val m = android.util.DisplayMetrics()
                @Suppress("DEPRECATION")
                wm.defaultDisplay.getRealMetrics(m)
                m.widthPixels to m.heightPixels
            }
            val ok = AutoClickAccessibilityService.click(w * 0.5f, h * 0.62f)
            LogBus.log(
                if (ok) "自检：已派发一次手势，看「点击完成 / 被取消」判断权限状态"
                else "自检失败：无障碍服务未连接，回系统设置重新打开开关"
            )
        }

        findViewById<Button>(R.id.btn_clear).setOnClickListener { LogBus.clear() }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }

        lifecycleScope.launch {
            LogBus.lines.collect {
                tvLog.text = it.joinToString("\n")
                refreshStatus()
            }
        }
        // 无障碍可能被 HyperOS 静默撤销，定时刷新状态灯
        lifecycleScope.launch {
            while (isActive) {
                refreshStatus()
                delay(1000)
            }
        }
        LogBus.log("就绪。顺序：① 无障碍 → ② 屏幕共享授权 → ③ 拨开「开始自动作答」")
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        val acc = AutoClickAccessibilityService.isReady
        val session = ScreenCaptureService.isSessionAlive()
        val running = ScreenCaptureService.isLoopRunning()

        tvStatus.text = buildString {
            appendLine("① 无障碍：${if (acc) "已连接 ✅" else "未开启 ❌"}")
            appendLine("② 屏幕共享：${if (session) "已授权 ✅" else "未授权 ❌"}")
            append("③ 自动作答：${if (running) "运行中 ▶" else "已暂停 ■"}")
        }

        // 只依赖会话；无障碍掉了也能把开关拨回「关」，拨「开」时监听里会拦住并提示
        switchRun.isEnabled = session
        updatingSwitch = true
        switchRun.isChecked = running
        switchRun.text = if (running) "■ 停止自动作答（正在运行）" else "▶ 开始自动作答"
        updatingSwitch = false
    }
}
