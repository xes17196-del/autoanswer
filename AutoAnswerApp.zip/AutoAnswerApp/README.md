# AutoAnswer — 本地屏幕识别 + 自动点击 Demo

一个**只在自己手机上跑**的 Android 工程：截取屏幕 → 端侧中文 OCR → 还原「题干 + 选项坐标」→ 本地策略选答案 → 无障碍手势点击。全程离线，不上传任何屏幕内容，不上架应用商店。

适合用来验证「屏幕理解 + 自动操作」这条链路，配合自建题库 / 自测类 App 玩。

## 运行链路

```
MediaProjection 截屏
      ↓ 降采样到 1080 宽（K80 Pro 是 2K 屏，直接全尺寸 OCR 又慢又吃内存）
ML Kit 中文 OCR（模型打包在 APK 内，无需 Google Play 服务）
      ↓ 每一行文本 + boundingBox 中心坐标
QuestionParser 用正则找出 A/B/C/D 行，前面的行拼成题干
      ↓
Solver 返回选项下标（没把握就返回 null，跳过不乱点）
      ↓ 坐标按缩放比例映射回真实屏幕
AccessibilityService.dispatchGesture 点击
      ↓ 冷却 1.2s，题干去重
下一题
```

## 环境与构建

- Android Studio Ladybug 或更新 / JDK 17 / Gradle 8.9
- 手机：红米 K80 Pro（HyperOS 2 / Android 15，工程 `compileSdk 35`、`targetSdk 35`、`minSdk 26`）

```bash
# 用 Android Studio 打开本目录即可；命令行需要先生成 wrapper jar
gradle wrapper --gradle-version 8.9
./gradlew assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

没有 wrapper jar 的话，直接用 Android Studio 的 **Build → Build APK(s)** 最省事，生成的 APK 在 `app/build/outputs/apk/debug/`。

## 红米 K80 Pro 授权清单（按顺序做）

1. **通知权限**：首次打开 App 会弹，允许。前台服务必须有通知。
2. **无障碍**：App 内点「1. 开启无障碍权限」→ 系统设置 → 已安装的服务 → AutoAnswer → 打开。这一步提供 `dispatchGesture` 模拟点击能力。
3. **截屏授权**：点「2. 授权截屏并开始」→ 系统弹「开始录制或投射屏幕？」→ 点「立即开始」。
   - Android 14+ 的 MediaProjection token 是**一次性的**，所以每次点「开始」都会重新弹一次窗，这是系统设计，不是 bug。
4. **HyperOS 保活**（不做的话锁屏几分钟服务容易被杀）：
   - 设置 → 应用设置 → 授权管理 → 自启动管理 → 允许 AutoAnswer
   - 应用详情页 → 省电策略 → 无限制
   - 最近任务里长按 App 卡片 → 点「锁定」
5. 可选：悬浮窗权限（本 Demo 没做悬浮控制面板，不授权也能跑）。

## 使用

打开任意**选择题**界面 → 回到 AutoAnswer 点「2. 授权截屏并开始」→ 再切到题目 App → 看 App 内日志滚动。点「停止」结束。

## 关键设计（为什么这么写）

- **不硬编码坐标**：点击位置直接来自 OCR 给出的选项文字包围盒，换 App、换分辨率、换字号都不用改代码。
- **一次 token、一次 VirtualDisplay**：Android 14+ 要求 `FOREGROUND_SERVICE_MEDIA_PROJECTION` 权限 + `foregroundServiceType="mediaProjection"` + 注册 `MediaProjection.Callback`；同一 MediaProjection 实例重复 `createVirtualDisplay()` 会抛 `SecurityException`。所以 VirtualDisplay 建一次，之后靠 `ImageReader.acquireLatestImage()` 持续取帧。
- **缩放坐标系映射**：OCR 在 1080 宽的图上跑，点击前乘回 `realW / 1080`，避免 2K 屏点位偏移。
- **答不准就跳过**：`Solver.solve()` 返回 `null` 时不动手，宁可空着也不瞎点。

## 能力边界 / 想继续加强

- 当前 `LocalRuleSolver` 只是**演示用关键词题库**（首都、水的化学式、1+1…），答对率完全取决于你换成什么。替换 `Solver` 实现类即可接：本地 SQLite 题库、端侧小模型、或你自己的 LLM 端点（网络请求放 IO 线程）。
- 只处理**文字选择题**。选项换行时 OCR 会拆成多行，点击坐标取首行中心（一般仍落在选项区域内）；图片题、公式题、拖拽题不支持。
- Flutter / WebView / 自绘 UI 拿不到控件树，本方案靠纯视觉 OCR，反而比 `AccessibilityNodeInfo` 更通用；反之，若是原生 App，可以加一条「优先读节点文本」的分支，识别会更准、也能拿到精确点击区域。
- 需要连续多题时可在点击后加「检测题目变化」再进下一轮，而不是固定 1.2s 冷却。

> 用途说明：这是本地自动化链路的技术验证，建议只在自建题库、自测类场景里跑；任何有明确规则的正式考核环境都不要带进去。
